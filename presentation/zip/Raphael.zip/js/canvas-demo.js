(function(){
	
	var paper = document.getElementById('demo-canvas'),
		ctx = paper.getContext("2d"),  //ctx is a very common convention for canvas, similar to e or evt for event
		rectOffsets = {
			x: 25,
			y: 50
		},
		rectSize = {
			x: 250,
			y: 250
		};
	
	
	//init method - kick us off by drawing the rectangle
	drawRect();
	
	
	/**
	 * this is where the magic happens.  it calls most of the other methods  
	 */
	function drawRect(){
		
		setCanvasSize();
		
		//eqv. to background color for an element
		ctx.fillStyle = 'gray';
		ctx.fillRect(rectOffsets.x, rectOffsets.y, rectSize.x, rectSize.y);
		
		drawText();
		
		//you can think of this like background color again, or even as "border color" since we're drawing a line
		drawOutline();
		
		//uncomment this to test the how things move differently if we forget our offsets
		// drawOutline2();
	}
	
	/**
	 * add some text to the canvas
	 */
	function drawText(text, color){
		ctx.fillStyle = color || 'black';
		ctx.fillText(text || 'hello world', 20, 20);
	}
	
	/**
	 * in this case, we are actually going to draw a line around the rectangle, so it will be a border, but not in the traditional CSS sense / syntax
	 * NOTE: we must keep track of where the pointer is.  This is where it gets tricky and debugger; in Chrome or Firefox will become your best friend.  Props to Joe Hewitt
	 */
	function drawOutline(color){
		var furthestRight = rectSize.x + rectOffsets.x, // we need that offset in addition to the X size in order to draw the border in the correct place
			furthestDown = rectSize.y + rectOffsets.y,
			topLeftCorner = rectOffsets.y;
			
		ctx.strokeStyle = color || 'red'; //think: 'border-color' 
		ctx.lineWidth = 5;  //think: border-width
		ctx.beginPath(); //tell Canvas we want to begin drawing with it
		
		//start where the rectangle starts by reusing it's offsets
		ctx.moveTo(rectOffsets.x, rectOffsets.y); 
				
		//moving only the x;  If we move Y, it will not be a straight line
		ctx.lineTo( furthestRight, rectOffsets.y); 
		
		//move just the Y now (drawing the far left vertical border)
		ctx.lineTo( furthestRight, furthestDown);
		
		//move just the x again.  see the pattern?
		ctx.lineTo( rectOffsets.x, furthestDown);
		
		//tell Canvas we're done computing this path; return to origin (our first moveTo() call)  
		ctx.closePath();
		//Draw it!
		ctx.stroke();
	}
	
	
	
	
	/** 
	 * what if we replaced the values for the offset with 0?  Let's see:
	 */
	function drawOutline2(color){
		ctx.strokeStyle = color || 'blue';
		ctx.beginPath();
		
		ctx.moveTo(rectOffsets.x, rectOffsets.y);
		
		//draw a line to what we THINK is the top right corner
		ctx.lineTo(rectSize.x, 0);
		
		//now bottom right
		ctx.lineTo(rectSize.x, rectSize.y);
		
		//bottom left
		ctx.lineTo(0, rectSize.y);
		
		//close it (return to origin)
		ctx.closePath();
		
		//draw it.
		ctx.stroke();
	}
	
	/**
	 * set the canvas deminsions 
	 */
	function setCanvasSize(x,y){
		paper.width = x || 1024;
		paper.height= y || 768;
	}
	
})();


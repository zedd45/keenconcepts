

SVG Maps:
http://www.weather.com/social/national/
http://jvectormap.owl-hollow.net/



SVG Interactive Menu:
http://thirteen23.com/


SVG used to create <video> tag Graphics:
http://svg-wow.org/videopatterns/videopattern.html
http://svg-wow.org/blog/category/ui/